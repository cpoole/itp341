/** Automatically generated file. DO NOT MODIFY */
package itp341.poole.connor.a3.app;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}