/** Automatically generated file. DO NOT MODIFY */
package itp341.lastname.firstname.a1.app;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}